document.write("NÚMEROS BINARIOS<br>");
document.write("Números binarios desde 0000 hasta 1111<br>");
document.write("-----------------------------<br><br>");
document.write("Número: 0000 = ");

var n;

n = 0 * (Math.pow(2,3)) + 0 * (Math.pow(2,2)) + 0 * (Math.pow(2,1)) + 0 * (Math.pow(2,0));

document.write(n + "<br>");

document.write("Número: 0001 = ");

var n;

n = 0 * (Math.pow(2,3)) + 0 * (Math.pow(2,2)) + 0 * (Math.pow(2,1)) + 1 * (Math.pow(2,0));

document.write(n + "<br>");

document.write("Número: 0010 = ");

var n;

n= 0 * (Math.pow(2,3)) + 0 * (Math.pow(2,2)) + 1 * (Math.pow(2,1)) + 0 * (Math.pow(2,0));

document.write(n + "<br>");

document.write("Número: 0011 = ");

var n;

n = 0 * (Math.pow(2,3)) + 0 * (Math.pow(2,2)) + 1 * (Math.pow(2,1)) + 1 * (Math.pow(2,0));

document.write(n + "<br>");

document.write("Número: 0100 = ");

var n;

n = 0 * (Math.pow(2,3)) + 1 * (Math.pow(2,2)) + 0 * (Math.pow(2,1)) + 0 * (Math.pow(2,0));

document.write(n + "<br>");

document.write("Número: 0101 = ");

var n;

n = 0 * (Math.pow(2,3)) + 1 * (Math.pow(2,2)) + 0 * (Math.pow(2,1)) + 1 * (Math.pow(2,0));

document.write(n + "<br>");

document.write("Número: 0110 = ");

var n;

n = 0 * (Math.pow(2,3)) + 1 * (Math.pow(2,2)) + 1 * (Math.pow(2,1)) + 0 * (Math.pow(2,0));

document.write(n + "<br>");

document.write("Número: 0111 =");

var n;

n = 0 * (Math.pow(2,3)) + 1 * (Math.pow(2,2)) + 1 * (Math.pow(2,1)) + 1 * (Math.pow(2,0));

document.write(n + "<br>");

document.write("Número: 1000 = ");

var n;

n = 1 * (Math.pow(2,3)) + 0 * (Math.pow(2,2)) + 0 * (Math.pow(2,1)) + 0 * (Math.pow(2,0));

document.write(n + "<br>");

document.write("Número: 1001 = ");

var n;

n = 1 * (Math.pow(2,3)) + 0 * (Math.pow(2,2)) + 0 * (Math.pow(2,1)) + 1 * (Math.pow(2,0));

document.write(n + "<br>");

document.write("Número: 1010 = ");

var n;

n = 1 * (Math.pow(2,3)) + 0 * (Math.pow(2,2)) + 1 * (Math.pow(2,1)) + 0 * (Math.pow(2,0));

document.write(n + "<br>");

document.write("Número: 1011 = ");

var n;

n = 1 * (Math.pow(2,3)) + 0 * (Math.pow(2,2)) + 1 * (Math.pow(2,1)) + 1 * (Math.pow(2,0));

document.write(n + "<br>");

document.write("Número: 1100 = ");

var n;

n = 1 * (Math.pow(2,3)) + 1 * (Math.pow(2,2)) + 0 * (Math.pow(2,1)) + 0 * (Math.pow(2,0));

document.write(n + "<br>");

document.write("Número: 1101 = ");

var n;

n = 1 * (Math.pow(2,3)) + 1 * (Math.pow(2,2)) + 0 * (Math.pow(2,1)) + 1 * (Math.pow(2,0));

document.write(n + "<br>");

document.write("Número: 1110 = ");

var n;

n = 1 * (Math.pow(2,3)) + 1 * (Math.pow(2,2)) + 1 * (Math.pow(2,1)) + 0 * (Math.pow(2,0));

document.write(n + "<br>");

document.write("Número: 1111 = ");

var n;

n = 1 * (Math.pow(2,3)) + 1 * (Math.pow(2,2)) + 1 * (Math.pow(2,1)) + 1 * (Math.pow(2,0));

document.write(n + "<br>");